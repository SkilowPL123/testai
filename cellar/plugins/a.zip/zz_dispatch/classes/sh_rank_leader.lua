CLASS.name = "Funkcjonariusz CCA - RL"
CLASS.faction = FACTION_MPF
CLASS.isDefault = false
CLASS.tag = "RL"
CLASS.rank = 2
CLASS_RL = CLASS.index
