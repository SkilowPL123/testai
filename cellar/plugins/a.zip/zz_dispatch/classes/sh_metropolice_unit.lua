CLASS.name = "Funkcjonariussz CP"
CLASS.faction = FACTION_MPF
CLASS.isDefault = true
CLASS.rank = 1
CLASS_MPF = CLASS.index