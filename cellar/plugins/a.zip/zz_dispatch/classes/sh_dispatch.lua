CLASS.name = "AI"
CLASS.faction = FACTION_DISPATCH
CLASS.isDefault = true
CLASS_DISPATCH = CLASS.index