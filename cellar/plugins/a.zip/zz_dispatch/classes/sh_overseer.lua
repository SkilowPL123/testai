CLASS.name = "Overseer"
CLASS.faction = FACTION_MPF2
CLASS.isDefault = true
CLASS_OVA = CLASS.index